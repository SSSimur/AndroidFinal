package com.example.newsapplication;

import com.example.newsapplication.Models.Articles;

import java.util.List;

public interface DataListener<ApiResponse> {
    void fetchData(List<Articles> list,String mes);
    void error(String mes);
}
