package com.example.newsapplication;

import com.example.newsapplication.Models.Articles;

public interface Select {
    void clicked(Articles articles);
}
