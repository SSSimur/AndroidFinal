package com.example.newsapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.newsapplication.Models.Articles;
import com.squareup.picasso.Picasso;

public class DetailsAct extends AppCompatActivity {
    Articles articles;
    TextView title, author,data,text,text2;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        title=findViewById(R.id.detailInfo_title);
        author=findViewById(R.id.author);
        data=findViewById(R.id.data);
        text=findViewById(R.id.detail_text);
        text2=findViewById(R.id.detail_text2);
        img=findViewById(R.id.detail_img);
        articles= (Articles) getIntent().getSerializableExtra("data");

        title.setText(articles.getTitle());
        author.setText(articles.getAuthor());
        data.setText(articles.getPublishedAt());
        text.setText(articles.getDescription());
        text2.setText(articles.getContent());
        Picasso.get().load(articles.getUrlToImage()).into(img);


    }
}