package com.example.newsapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.newsapplication.Models.ApiResponse;
import com.example.newsapplication.Models.Articles;

import java.util.List;

public class MainActivity extends AppCompatActivity implements Select, View.OnClickListener{
    RecyclerView recyclerView;
    CustomAdapter adapter;
    ProgressDialog dialog;
    Button b1,b2,b3,b4,b5,b6,b7;
    SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        searchView=findViewById(R.id.search_bar);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                RequestManager manager=new RequestManager(MainActivity.this);
                manager.getNewsHeadlines(responseDataListener,"general",query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        RequestManager manager=new RequestManager(this);
        manager.getNewsHeadlines(responseDataListener,"general",null);
        dialog=new ProgressDialog(this);
        b1=findViewById(R.id.b1);
        b2=findViewById(R.id.b2);
        b3=findViewById(R.id.b3);
        b4=findViewById(R.id.b4);
        b5=findViewById(R.id.b5);
        b6=findViewById(R.id.b6);
        b7=findViewById(R.id.b7);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);
        b7.setOnClickListener(this);
    }
    private final DataListener<ApiResponse> responseDataListener=new DataListener<ApiResponse>() {
        @Override
        public void fetchData(List<Articles> list, String mes) {
            if(list.isEmpty()){
                Toast.makeText(MainActivity.this,"No Article found!",Toast.LENGTH_LONG).show();
            }
            else {
                showNews(list);
            }
        }

        @Override
        public void error(String mes) {
            Toast.makeText(MainActivity.this,"Error!",Toast.LENGTH_LONG).show();

        }
    };

    private void showNews(List<Articles> list) {
        recyclerView=findViewById(R.id.recycleView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        adapter=new CustomAdapter(this,list,this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void clicked(Articles articles) {
        startActivity(new Intent(MainActivity.this,DetailsAct.class)
        .putExtra("data",articles));

    }

    @Override
    public void onClick(View view) {
        Button button=(Button) view;
        String category=button.getText().toString();
        RequestManager manager=new RequestManager(this);
        manager.getNewsHeadlines(responseDataListener,category,null);

    }
}
