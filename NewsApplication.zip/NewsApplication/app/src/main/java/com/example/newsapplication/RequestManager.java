package com.example.newsapplication;

import android.content.Context;
import android.widget.Toast;

import com.example.newsapplication.Models.ApiResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Query;

public class RequestManager {
    Context context;
    Retrofit retrofit=new Retrofit.Builder()
                    .baseUrl("https://newsapi.org/v2/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

    public void getNewsHeadlines(DataListener dataListener,String category,String query){
        NewsApi newsApi=retrofit.create(NewsApi.class);
        Call<ApiResponse> call=newsApi.call("ru",category,query,context.getString(R.string.api_key));
        try {
            call.enqueue(new Callback<ApiResponse>() {
                @Override
                public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                    if(!response.isSuccessful()){
                        Toast.makeText(context,"Error!",Toast.LENGTH_LONG).show();
                    }
                    dataListener.fetchData(response.body().getArticles(),response.message());

                }

                @Override
                public void onFailure(Call<ApiResponse> call, Throwable t) {
                    dataListener.error("Request Failed!");

                }
            });
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public RequestManager(Context context) {
        this.context = context;
    }
    public interface NewsApi{
        @GET("top-headlines")
        Call<ApiResponse> call(
                @Query("country") String country,
                @Query("category") String category,
                @Query("q") String query,
                @Query("apiKey") String api_ley
        );
    }
}
